package tile;


import java.awt.*;
import java.awt.image.BufferedImage;

public class Tile
{
    public BufferedImage image;
    public Rectangle solidArea;
    public boolean collision = false;
}
